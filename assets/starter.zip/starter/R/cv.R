# Generate the CV as a Word file from the structured records in data/.
# Run from the project root (open the RStudio project first).
# Output goes to cv/, which Git ignores.

library(officer)
if (!"run_tab" %in% getNamespaceExports("officer")) {
  stop(paste0("This CV requires officer::run_tab; installed officer ",
              as.character(utils::packageVersion("officer")),
              " does not export it. Review an officer upgrade in the selected R library, ",
              "then restart R and retry. No packages were installed."), call. = FALSE)
}
library(yaml)
source("R/citations.R")

# ---- Settings ----------------------------------------------------------------

styles_file  <- "templates/cv-styles.docx"  # formatting only; see the styles in Word
private_file <- "cv/private.yml"     # name, address, email: kept out of the public repo
if (!grepl("^[a-z0-9][a-z0-9-]*$", site_config$output_basename)) stop("Choose a simple output_basename")
# Setup pins this simple filename in its reviewed command and expected_files.
output_name <- getOption("academic_records.cv_filename")
if (is.null(output_name)) {
  output_name <- paste0(site_config$output_basename, "-CV-", Sys.Date(), ".docx")
}
if (!is.character(output_name) || length(output_name) != 1L || is.na(output_name) ||
    !grepl("^[A-Za-z0-9][A-Za-z0-9._-]*[.]docx$", output_name)) {
  stop("CV filename must be a simple .docx filename inside cv/; review the exact output name.")
}
output_file <- file.path("cv", output_name)
if (file.exists(output_file)) stop("CV output already exists; preserve it and choose a reviewed new output name")
dir.create("cv", showWarnings = FALSE)

`%||%` <- function(a, b) if (is.null(a)) b else a

read_records <- function(name) {
  read_starter_records(name)
}

# ---- Dates -------------------------------------------------------------------
# Dates in data/ are ISO strings at whatever precision is known:
# "2009", "2012-10" or "2018-04-13". end_date can also be "present" or null.
# Never call as.Date() on them directly.

# "2009" -> "2009"; "2012-10" -> "10/2012"; "2018-04-13" -> "4/13/2018"
cv_date <- function(x) {
  if (is.null(x)) return("")
  if (x == "present") return("present")
  p <- as.integer(strsplit(x, "-", fixed = TRUE)[[1]])
  switch(length(p),
         as.character(p[1]),
         paste0(p[2], "/", p[1]),
         paste0(p[2], "/", p[3], "/", p[1]))
}

# "2002-06" -> "June 2002"
cv_month_year <- function(x) {
  if (is.null(x)) return("")
  p <- as.integer(strsplit(x, "-", fixed = TRUE)[[1]])
  if (length(p) == 1) return(as.character(p))
  paste(month.name[p[2]], p[1])
}

# start and end -> "6/2006-6/2009"; a null end gives "11/1/2026-"
cv_range <- function(start, end) {
  if (is.null(end)) return(paste0(cv_date(start), "-"))
  if (identical(start, end)) return(cv_date(start))
  paste0(cv_date(start), "-", cv_date(end))
}

# Sort oldest first. Ties keep their order in the YAML file.
sort_by_date <- function(records, field = "start_date") {
  records[order(vapply(records, \(r) r[[field]] %||% "", character(1)))]
}

# Report records whose stored date_text no longer matches their dates
check_dates <- function(records, file) {
  for (r in records) {
    if (is.null(r$date_text)) next
    got <- cv_range(r$start_date, r$end_date)
    if (got != r$date_text) {
      message(file, ": ", r$id, " dates give '", got,
              "' but date_text is '", r$date_text, "'")
    }
  }
}

# ---- Building blocks -----------------------------------------------------------

bold <- fp_text_lite(bold = TRUE)
ital <- fp_text_lite(italic = TRUE)

# One entry: date, tab, first line; then detail lines under the text column.
# first can be plain text or a list of ftext() pieces.
add_entry <- function(doc, date, first, details = character(0), first_bold = FALSE) {
  if (is.character(first)) {
    first <- list(ftext(first, if (first_bold) bold else NULL))
  }
  doc <- body_add_fpar(doc, do.call(fpar, c(list(ftext(date), run_tab()), first)),
                       style = "CV Entry")
  for (d in details) {
    if (inherits(d, "fpar")) {
      doc <- body_add_fpar(doc, d, style = "CV Detail")
    } else {
      doc <- body_add_par(doc, d, style = "CV Detail")
    }
  }
  doc
}

# "Bronx, NY", or a location such as "Remote" when there is no city
place <- function(r) {
  if (!is.null(r$city)) paste0(r$city, ", ", r$state) else r$location %||% character(0)
}

# ---- Sections ----------------------------------------------------------------

add_header <- function(doc, p) {
  doc <- body_add_par(doc, "CURRICULUM VITAE", style = "CV Title")
  doc <- body_add_par(doc, p$name, style = "CV Name")
  for (line in p$address) {
    doc <- body_add_fpar(doc, fpar(ftext(line, bold)), style = "CV Contact")
  }
  if (!is.null(p$email) && nzchar(p$email)) doc <- body_add_fpar(doc, fpar(hyperlink_ftext(p$email, href = paste0("mailto:", p$email))),
                       style = "CV Contact")
  if (!is.null(p$website) && nzchar(p$website)) doc <- body_add_fpar(doc, fpar(hyperlink_ftext(p$website, href = p$website)),
                       style = "CV Contact")
  doc
}

add_education <- function(doc, records) {
  if (!length(records)) return(doc)
  check_dates(records, "education.yml")
  doc <- body_add_par(doc, "Education", style = "CV Section")
  for (r in sort_by_date(records)) {
    degree <- fpar(
      ftext(paste0("Degree: ", r$degree, if (!is.null(r$honors)) " ")),
      ftext(r$honors %||% "", ital),
      ftext(paste0(", ", cv_month_year(r$degree_date)))
    )
    details <- list(place(r), degree)
    if (!is.null(r$major)) details <- c(details, paste0("Major: ", r$major))
    if (!is.null(r$certificates)) {
      details <- c(details, paste("Language certificates in",
                                  paste(r$certificates, collapse = " and in ")))
    }
    doc <- add_entry(doc, cv_range(r$start_date, r$end_date), r$institution,
                     details, first_bold = TRUE)
  }
  doc
}

add_training <- function(doc, records) {
  if (!length(records)) return(doc)
  check_dates(records, "training.yml")
  doc <- body_add_par(doc, "Postgraduate Training", style = "CV Section")
  for (r in sort_by_date(records)) {
    doc <- add_entry(doc, cv_range(r$start_date, r$end_date), r$institution,
                     c(place(r), r$role), first_bold = TRUE)
  }
  doc
}

add_appointments <- function(doc, records) {
  check_dates(records, "appointments.yml")
  # Records listing cv_sections appear only in the sections they name
  keep <- vapply(records, \(r) is.null(r$cv_sections) || "appointments" %in% r$cv_sections,
                 logical(1))
  if (!any(keep)) return(doc)
  doc <- body_add_par(doc, "Professional Employment and Hospital Appointments",
                      style = "CV Section")
  for (r in sort_by_date(records[keep])) {
    doc <- add_entry(doc, cv_range(r$start_date, r$end_date), r$title,
                     c(r$institution, place(r)))
  }
  doc
}

add_certifications <- function(doc, records) {
  if (!length(records)) return(doc)
  check_dates(records, "certifications.yml")
  doc <- body_add_par(doc, "Board Certification", style = "CV Section")
  for (r in sort_by_date(records)) {
    doc <- add_entry(doc, cv_range(r$start_date, r$end_date),
                     paste(r$title, r$board, r$specialty, sep = ", "))
  }
  doc
}

add_memberships <- function(doc, records) {
  if (!length(records)) return(doc)
  check_dates(records, "memberships.yml")
  doc <- body_add_par(doc, "Professional Society Membership", style = "CV Section")
  for (r in sort_by_date(records)) {
    doc <- add_entry(doc, cv_range(r$start_date, r$end_date), r$society)
  }
  doc
}

add_honors <- function(doc, records) {
  if (!length(records)) return(doc)
  doc <- body_add_par(doc, "Awards and Honors", style = "CV Section")
  for (r in sort_by_date(records, "date")) {
    doc <- add_entry(doc, cv_date(r$date), r$title,
                     c(r$program, r$institution, place(r)))
  }
  doc
}

# "2006-05-06" -> "May 6, 2006"; less precise dates fall back to "May 2006"
cv_long_date <- function(x) {
  p <- as.integer(strsplit(x, "-", fixed = TRUE)[[1]])
  if (length(p) < 3) return(cv_month_year(x))
  paste0(month.name[p[2]], " ", p[3], ", ", p[1])
}

money <- function(x) {
  paste0("$", formatC(x, format = "f", digits = if (x %% 1 == 0) 0 else 2, big.mark = ","))
}

quoted <- function(x) paste0("\u201c", end_sentence(x), "\u201d")

# Turn **bold** and *italic* marks into formatted Word text
md_pieces <- function(x) {
  parts <- regmatches(x, gregexpr("\\*\\*[^*]+\\*\\*|\\*[^*]+\\*|[^*]+", x))[[1]]
  lapply(parts, function(s) {
    if (startsWith(s, "**")) ftext(gsub("^\\*\\*|\\*\\*$", "", s), bold)
    else if (startsWith(s, "*")) ftext(gsub("^\\*|\\*$", "", s), ital)
    else ftext(s)
  })
}

# Numbered list (bibliography), restarting at 1 for each list
add_numbered <- function(doc, items) {
  for (i in seq_along(items)) {
    pieces <- c(list(ftext(paste0(i, ".")), run_tab()), md_pieces(items[[i]]))
    doc <- body_add_fpar(doc, do.call(fpar, pieces), style = "CV Numbered")
  }
  doc
}

add_service <- function(doc, service, appointments) {
  extra <- Filter(\(r) r$category == "extramural", service)
  intra <- Filter(\(r) r$category == "intramural", service)
  shared <- Filter(\(r) "service" %in% r$cv_sections, appointments)
  shared <- lapply(shared, \(r) c(r, list(role = r$title, activity = NULL)))
  if (!length(extra) && !length(intra) && !length(shared)) return(doc)
  check_dates(service, "service.yml")
  doc <- body_add_par(doc, "Other Professional Activities", style = "CV Section")
  if (length(extra)) {
    doc <- body_add_par(doc, "Extramural Activities:", style = "CV Subsection")
    for (r in sort_by_date(extra)) {
      doc <- add_entry(doc, cv_range(r$start_date, r$end_date),
                       list(ftext(paste0(r$role, ", ")), ftext(r$venue, ital)))
    }
  }
  if (length(intra) || length(shared)) {
    doc <- body_add_par(doc, "Intramural Activities:", style = "CV Subsection")
    for (r in sort_by_date(c(intra, shared))) {
      first <- paste(c(r$role, r$activity), collapse = ", ")
      doc <- add_entry(doc, cv_range(r$start_date, r$end_date), first,
                       c(r$unit, r$institution, place(r)))
    }
  }
  doc
}

add_talks <- function(doc, records) {
  headings <- c(
    invited = "Invited Presentations",
    conference = "Conference Presentations",
    grand_rounds = "Grand Rounds",
    teaching = "Teaching Presentations"
  )
  for (r in records) {
    if (!is.character(r$category) || length(r$category) != 1L ||
        is.na(r$category) || !r$category %in% names(headings)) {
      stop("Talk category is missing or unsupported; confirm it before generating the CV.")
    }
  }
  for (category in names(headings)) {
    group <- Filter(function(r) identical(r$category, category), records)
    if (!length(group)) next
    doc <- body_add_par(doc, headings[[category]], style = "CV Section")
    for (r in sort_by_date(group, "date")) {
      where <- paste(c(r$role, r$venue, if (!is.null(r$city)) place(r)), collapse = ", ")
      doc <- add_entry(doc, cv_date(r$date), paste0(where, ". ", quoted(r$title)))
    }
  }
  doc
}

add_grants <- function(doc, records) {
  if (!length(records)) return(doc)
  check_dates(records, "grants.yml")
  doc <- body_add_par(doc, "Research", style = "CV Section")
  doc <- body_add_par(doc, "Grant Support", style = "CV Subsection")
  for (r in sort_by_date(records)) {
    doc <- add_entry(doc, cv_range(r$start_date, r$end_date),
                     paste0(paste(c(r$sponsor, if (!is.null(r$award_number) &&
                       nzchar(trimws(r$award_number))) r$award_number), collapse = " "), "."),
                     c(quoted(r$title),
                       paste0("Total support: ", money(r$total_support)),
                       paste0("Role: ", r$role)))
  }
  doc
}

format_abstract <- function(r) {
  kind <- if (r$type == "oral") "Oral presentation" else "Poster presentation"
  where <- paste(c(r$meeting, cv_long_date(r$date), if (!is.null(r$city)) place(r)),
                 collapse = ", ")
  paste(c(if (!is.null(r$authors)) bold_me(end_sentence(r$authors)),
          end_sentence(r$title),
          paste0(kind, " at ", end_sentence(where)),
          if (!is.null(r$award)) end_sentence(paste0("Award: ", r$award))),
        collapse = " ")
}

add_bibliography <- function(doc, pubs, abstracts) {
  articles <- pubs[pubs$type == "article", ]
  chapters <- pubs[pubs$type == "chapter", ]
  website <- site_config$website
  has_website <- !is.null(website) && length(website) == 1L &&
    !is.na(website) && nzchar(trimws(website))
  if (!nrow(articles) && !nrow(chapters) && !length(abstracts) && !has_website) return(doc)
  doc <- body_add_par(doc, "Bibliography", style = "CV Section")
  if (nrow(articles)) {
    doc <- body_add_par(doc, "A. Original Contributions in Reviewed Journals:", style = "CV Subsection")
    doc <- add_numbered(doc, lapply(seq_len(nrow(articles)), \(i) format_citation(articles[i, ])))
  }
  if (nrow(chapters)) {
    doc <- body_add_par(doc, "B. Books, Chapters in Books, and Review Articles:", style = "CV Subsection")
    doc <- add_numbered(doc, lapply(seq_len(nrow(chapters)), \(i) format_citation(chapters[i, ])))
  }
  if (length(abstracts)) {
    doc <- body_add_par(doc, "C. Abstracts:", style = "CV Subsection")
    doc <- add_numbered(doc, lapply(sort_by_date(abstracts, "date"), format_abstract))
  }
  if (has_website) {
    doc <- body_add_par(doc, "D. Websites", style = "CV Subsection")
    doc <- body_add_par(doc, website, style = "Normal")
  }
  doc
}

# ---- Build -------------------------------------------------------------------

doc <- read_docx(styles_file)
private_header <- if (file.exists(private_file)) yaml::read_yaml(private_file, eval.expr = FALSE) else
  list(name = site_config$display_name, address = list(), email = NULL, website = site_config$website)
doc <- add_header(doc, private_header)
doc <- add_education(doc, read_records("education"))
doc <- add_training(doc, read_records("training"))
doc <- add_appointments(doc, read_records("appointments"))
doc <- add_certifications(doc, read_records("certifications"))
doc <- add_memberships(doc, read_records("memberships"))
doc <- add_honors(doc, read_records("honors"))
doc <- add_service(doc, read_records("service"), read_records("appointments"))
doc <- add_talks(doc, read_records("talks"))
doc <- add_grants(doc, read_records("grants"))
doc <- add_bibliography(doc, read_publications(), read_records("abstracts"))

# Remove the empty paragraph the styles file starts with
doc <- cursor_begin(doc)
doc <- body_remove(doc)

print(doc, target = output_file)
message("Wrote ", output_file)