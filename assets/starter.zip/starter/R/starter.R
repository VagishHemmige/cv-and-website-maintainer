# Shared public configuration and empty-section handling for the starter.
site_config <- yaml::read_yaml("site.yml", eval.expr = FALSE)
read_starter_records <- function(name) {
  yaml::read_yaml(file.path("data", paste0(name, ".yml")), eval.expr = FALSE) %||% list()
}
`%||%` <- function(a, b) if (is.null(a)) b else a
read_starter_table <- function(name, fields, list_fields = character()) {
  rows <- lapply(read_starter_records(name), function(row) {
    for (key in list_fields) row[[key]] <- list(unlist(row[[key]], use.names = FALSE))
    row
  })
  result <- dplyr::bind_rows(rows)
  for (field in fields) if (!field %in% names(result)) result[[field]] <- rep(NA_character_, nrow(result))
  for (field in list_fields) if (!field %in% names(result)) result[[field]] <- vector("list", nrow(result))
  result
}
read_starter_bib <- function() {
  path <- file.path("data", site_config$bibliography_file)
  if (!file.exists(path)) stop("Configured bibliography is missing")
  if (!nzchar(trimws(paste(readLines(path, warn = FALSE), collapse = "")))) return(list())
  RefManageR::ReadBib(path, check = FALSE)
}
